class pqueue
{
    Node n;
    pqueue next=null;
}
