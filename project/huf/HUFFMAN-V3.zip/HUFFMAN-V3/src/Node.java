class Node
{
    char ch;
    int count;
    Node left=null;
    Node right=null;
    Node parent=null;
    String code="\0";
    int cc=0;
}
